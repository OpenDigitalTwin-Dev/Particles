The lammps.xml file in this dir is for use with the Kate editor
in the KDE suite, to do syntax highlighting for LAMMPS input
scripts.

The author is Alessandro Luigi Sellerio <alessandro.sellerio@ieni.cnr.it>.
Please contact him with questions.
