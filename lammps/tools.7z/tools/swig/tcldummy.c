int i_am_a_dummy_function()
{
     return 0;
}

