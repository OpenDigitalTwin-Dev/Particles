
mkdir -p gnu-make
mkdir -p cmake
export KOKKOS_PATH=$1
KOKKOS_PATH=$1
${KOKKOS_PATH}/core/unit_test/configuration/test-code/test_config_device_list.bash

