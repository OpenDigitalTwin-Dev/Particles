# Incremental testing for test-driven development

This sequence of tests aims to provide a clear implementation path for developing new backends. The idea being, if one can get these tests to pass in sequence, failures in the broader test suite of the parent directory should become more informative about more obscure errors.